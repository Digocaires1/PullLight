import { useState } from 'react'
import './App.css'
import Logo from './assets/Logo.png'
import insta from './assets/insta.png'
import youtu from './assets/youtu.png'
import jogo1 from './assets/jogo1.png'
import jogo2 from './assets/jogo2.png'
import jogo3 from './assets/jogo3.png'


function App() {

  const [indice,setIndice]= useState(1)

    const games={
      1:{
        titulo: <h2>TOP1 mais jogado dessa semana: V7X Nightmare - Jogadores: 25.2k - Avaliação: 9.8</h2>,
        imagem: jogo1

      },
      2:{
        titulo: <h2>TOP2 mais jogado dessa semana: Strange House - Jogadores: 22k - Avaliação: 9.0</h2>,
        imagem: jogo2
      },
      3:{
        titulo: <h2>TOP3 mais jogado dessa semana: Echoes of the Pine - Jogadores: 19.7k - Avaliação: 9.2</h2>,
        imagem: jogo3
      }

    }

  function TrocarJogo(){
    setIndice(indice === 3 ? 1: indice + 1)

  }

  return(

<div className='Fundo'>

    <div className='cabecalho'>
      <div className='logo' onClick={() => window.location.href = "/"}>
        <img src={Logo} alt="Logo PullLight"></img>
      </div>
        <div className='Outros'>
          <h1>Perfil</h1>
          <h1 className='Perfil'>Pagina Inicial</h1>
          <h1>Procurar</h1>
        </div>
    </div>

    <div className='Corpo'>
      <div className='Destaque'>
          <div className='jogos'>
            <div className='imagem'><img src={games[indice].imagem} alt="casa assombrada" onClick={TrocarJogo}></img></div>
          </div>
          <div className='detalhes'>{games[indice].titulo}</div>
      </div>
      <div className='OutrosJogos'>
          <div className="retangulo">Jogo 1</div>
          <div className="retangulo">Jogo 2</div>
          <div className="retangulo">Jogo 3</div>
          <div className="retangulo">Jogo 4</div>
          <div className="retangulo">Jogo 5</div>
          <div className="retangulo">Jogo 6</div>
          <div className="retangulo">Jogo 7</div>
          <div className="retangulo">Jogo 8</div>
          <div className="retangulo">Jogo 9</div>
          <div className="retangulo">Jogo 10</div>
          <div className="retangulo">Jogo 11</div>
          <div className="retangulo">Jogo 12</div>
          <div className="retangulo">Jogo 13</div>
          <div className="retangulo">Jogo 14</div>
          <div className="retangulo">Jogo 15</div>
          <div className="retangulo">Jogo 16</div>
          <div className="retangulo">Jogo 17</div>
          <div className="retangulo">Jogo 18</div>
          <div className="retangulo">Jogo 19</div>
          <div className="retangulo">Jogo 20</div>
          <div className="retangulo">Jogo 21</div>
          <div className="retangulo">Jogo 22</div>
          <div className="retangulo">Jogo 23</div>
          <div className="retangulo">Jogo 24</div>
          <div className="retangulo">Jogo 25</div>
          <div className="retangulo">Jogo 26</div>
          <div className="retangulo">Jogo 27</div>
          <div className="retangulo">Jogo 28</div>
          <div className="retangulo">Jogo 29</div>
          <div className="retangulo">Jogo 30</div>
          <div className="retangulo">Jogo 31</div>
          <div className="retangulo">Jogo 32</div>
          <div className="retangulo">Jogo 33</div>
          <div className="retangulo">Jogo 34</div>
          <div className="retangulo">Jogo 35</div>
          <div className="retangulo">Jogo 36</div>
          <div className="retangulo">Jogo 37</div>
          <div className="retangulo">Jogo 38</div>
          <div className="retangulo">Jogo 39</div>
          <div className="retangulo">Jogo 40</div>
          <div className="retangulo">Jogo 41</div>
          <div className="retangulo">Jogo 42</div>
          <div className="retangulo">Jogo 43</div>
          <div className="retangulo">Jogo 44</div>
          <div className="retangulo">Jogo 45</div>
          <div className="retangulo">Jogo 46</div>
          <div className="retangulo">Jogo 47</div>
          <div className="retangulo">Jogo 48</div>
          <div className="retangulo">Jogo 49</div>
          <div className="retangulo">Jogo 50</div>
          
      </div>
</div>

    <div className='Sobre'>
      <div className='Sobre2'>
        <div className='Assistencias'>
          <p>
          <h1 className='Perfil'>Sobre</h1>
          <h1 className='Perfil'>Assistencia</h1>
          <h1 className='Perfil'>Configurações</h1>
          </p>
        </div>
        <div className='Redes'>
          <img src={insta} alt='Instagram Logo' className='insta'></img>
          <img src={youtu} alt='Youtube Logo'   className='youtu'></img>
        </div>
      </div>
    </div>   

</div>
  )
}
export default App
